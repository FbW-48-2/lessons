const ul = document.querySelector('ul');
console.log(ul);

//child nodes
let result;
result = ul.childNodes
result = ul.childNodes[2]


// children
result = ul.children
result = ul.children[0].className
//ul.children[0].style="color:red; font-weight:bold;"
// Array.from(ul.children).forEach(item => {
//     item.style.color = "green"
// });
const [first,second,third] = ul.children // destructuring 

//console.log('first: ',first);

// children of children
result = ul.children[0].children[0]
result.style.color = "red";

// first child
result = ul.firstChild
result = ul.firstElementChild.firstElementChild

// last child
result = ul.lastChild
console.log(result);